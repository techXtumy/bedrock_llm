"""Tests for bedrock_be."""
