"""WEB API for bedrock_be."""
