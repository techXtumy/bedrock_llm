"""Services for bedrock_be."""
