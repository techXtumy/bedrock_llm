"""API for checking project status."""

from bedrock_be.web.api.monitoring.views import router

__all__ = ["router"]
